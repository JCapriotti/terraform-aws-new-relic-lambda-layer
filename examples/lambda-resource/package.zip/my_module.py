def handler(event, context):
    print("Hello from app!")

    return event
